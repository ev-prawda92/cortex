# Cortex — Agent Control Plane

A single-file control plane for managing a portfolio of AI agents: monitor their
health, edit their configuration in plain English behind a human-approval gate,
track every change with versioning and one-click revert, and triage failures as
config issues vs. platform bugs.

Built as a working prototype of one idea: **as organizations deploy many agents,
someone has to monitor, configure, and be accountable for them — and the operator
is often a domain expert, not an engineer.** Cortex is the surface for that person.

## Run it

```
python3 cortex.py
```

Then open http://localhost:3000. No build step, no npm — one Python file.

Dependencies: `fastapi`, `uvicorn`, `httpx`. Install with:

```
pip install fastapi uvicorn httpx
```

Or just run `./start.sh`, which installs them and starts the server.

## The live agent

`agent.py` is a **real agent**, not seed data. Given a claim it searches the live
web, reads sources, and decides for itself what to check next — a genuine
think → act → observe loop — then either concludes with citations or escalates to
a human because it couldn't ground the claim.

```
export ANTHROPIC_API_KEY=sk-...
python3 agent.py "The Washington Post was founded in 1877"
```

Or run it from the Cortex UI: open the **Editorial Verification ⚡ LIVE** agent in
the Control tab and enter a claim.

The point of the integration: **Cortex's config actually governs it.** Edit the
agent's config in plain English, approve the diff, and the next run behaves
differently — `max_retries` is its investigation budget, `confidence_threshold`
decides when a result is held for review, `confirm_then_act` decides whether
anything can publish without a human. Raise the threshold above the agent's own
confidence and the exact same finding flips from published to held.

## What's in it

Four tabs, all sharing one live agent store — a change in one is reflected everywhere:

- **Monitor** — portfolio health at a glance: containment, resolution, escalation,
  clinical flags, and a per-agent table. Click any agent to open it in Control.
- **Control** — pick an agent, see its real structured config, and change it in
  plain English ("wait 48 hours before the first call, escalate to nursing below
  0.8 confidence"). Cortex proposes a diff, shows before/after, and **applies
  nothing until you approve.** Risky changes (e.g. disabling confirm-then-act) are
  flagged.
- **History** — every applied change to an agent, versioned and timestamped, with
  one-click revert.
- **Diagnostics** — two worked examples of the core triage call: is a failure a
  config issue you fix yourself, or a platform bug you hand to engineering with
  evidence?

## The design point

The plain-English editing is the convenient part. The **gate** is the important
part: a live agent is never silently mutated. Every consequential change is
proposed, previewed, approved by a human, logged, and reversible. That's what makes
it safe to hand config control to a non-engineer operating agents in a high-stakes
setting.

## What's real vs. illustrative

Being honest about the prototype's status:

- **Real:** the plain-English → config-diff → approve → apply → version → revert
  flow works end to end. With `ANTHROPIC_API_KEY` set, the translation uses the
  model for any phrasing; without it, a rule-based parser handles the common change
  types (timing, retries, channel, call window, confidence threshold, escalation
  severity, confirm-then-act).
- **Real:** `agent.py` is a working agent loop with live web search, real model
  reasoning, and the config-driven gate deciding publish vs. hold.
- **Illustrative:** the other 12 agents are seed data. They aren't live agents making
  calls or writing to systems, and the diagnostics examples are hand-written to
  demonstrate the triage reasoning. Cortex is a control-plane prototype — in
  production it would wire into whatever runtime the agents actually run on.

## Configuration

```
ANTHROPIC_API_KEY   optional — enables model-assisted plain-English translation
ANTHROPIC_MODEL     optional — defaults to a current Claude model
```

Runs fully offline in rule-based mode without any key.
