#!/bin/bash
pip install --quiet --break-system-packages fastapi uvicorn httpx 2>/dev/null
python3 cortex.py
